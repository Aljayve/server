import { Prop, Schema, SchemaFactory } from "@nestjs/mongoose";
import { HydratedDocument, Types } from "mongoose";
import { Schema as MongooseSchema } from "mongoose";

export type ResumeDocument =
    HydratedDocument<Resume>;


@Schema({
    timestamps: true,
})
export class Resume {
    @Prop({
        type: Types.ObjectId,
        ref: "User",
        required: true,
    })
    userId: Types.ObjectId;

    @Prop({
        required: true,
    })
    title: string;

    @Prop({
        default: "ats-classic",
    })
    template: string;

    @Prop({
        default: 0,
    })
    atsScore: number;

    @Prop({
        type: MongooseSchema.Types.Mixed,
        default: {},
    })
    content: Record<string, any>;

    @Prop({
        default: false,
    })
    isArchived: boolean;
}

export const ResumeSchema =
    SchemaFactory.createForClass(
        Resume,
    );