import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { Resume, ResumeSchema } from './schemas/resume.schema';
import { ResumesService } from './resumes.service';
import { ResumesController } from './resumes.controller';
import { UploadModule } from '../uploads/upload.module';

@Module({
    imports: [
        MongooseModule.forFeature([
            {
                name: Resume.name,
                schema: ResumeSchema,
            },
        ]),
        UploadModule,
    ],

    controllers: [
        ResumesController,
    ],

    providers: [
        ResumesService,
    ],

    exports: [
        ResumesService,
    ],
})
export class ResumesModule { }
