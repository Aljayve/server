import { Injectable, NotFoundException } from "@nestjs/common";
import { InjectModel } from "@nestjs/mongoose";
import { Resume, ResumeDocument } from "./schemas/resume.schema";
import { Model } from "mongoose";
import { CreateResumeDto } from "./dto/create-resume.dto";
import { UpdateResumeDto } from "./dto/update-resume.dto";

@Injectable()
export class ResumesService {
    constructor(
        @InjectModel(Resume.name)
        private readonly resumeModel: Model<ResumeDocument>,
    ) { }


    async create(
        userId: string,
        dto: CreateResumeDto,
    ) {
        return this.resumeModel.create({
            ...dto,
            userId,
        });
    }

    async findAll(userId: string) {
        return this.resumeModel
            .find({
                userId,
                isArchived: false,
            })
            .sort({
                updatedAt: -1,
            });
    }

    async findOne(
        id: string,
        userId: string,
    ) {
        const resume =
            await this.resumeModel.findOne({
                _id: id,
                userId,
            });

        if (!resume) {
            throw new NotFoundException(
                "Resume not found",
            );
        }

        return resume;
    }

    async findById(id: string) {
        const resume = await this.resumeModel.findById(id);

        if (!resume) {
            throw new NotFoundException(
                "Resume not found",
            );
        }

        return resume;
    }

    async update(
        id: string,
        userId: string,
        dto: UpdateResumeDto,
    ) {
        const resume =
            await this.resumeModel.findOneAndUpdate(
                {
                    _id: id,
                    userId,
                },
                dto,
                {
                    returnDocument: 'after',
                },
            );

        if (!resume) {
            throw new NotFoundException(
                "Resume not found",
            );
        }

        return resume;
    }

    async updatePhoto(
        id: string,
        userId: string,
        photoUrl: string,
    ) {
        const resume = await this.resumeModel.findOneAndUpdate(
            { _id: id, userId },
            { $set: { "content.personalInfo.photo": photoUrl } },
            { returnDocument: 'after' },
        ).exec();

        if (!resume) {
            throw new NotFoundException(
                "Resume not found",
            );
        }

        return resume;
    }

    async remove(
        id: string,
        userId: string,
    ) {
        const resume =
            await this.resumeModel.findOneAndUpdate(
                {
                    _id: id,
                    userId,
                },
                {
                    isArchived: true,
                },
                {
                    returnDocument: 'after',
                },
            );

        if (!resume) {
            throw new NotFoundException(
                "Resume not found",
            );
        }

        return {
            message: "Resume archived successfully",
        };
    }
}