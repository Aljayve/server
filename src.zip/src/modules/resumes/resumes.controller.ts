import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards, UseInterceptors, UploadedFile } from "@nestjs/common";
import { ResumesService } from "./resumes.service";
import { CreateResumeDto } from "./dto/create-resume.dto";
import { UpdateResumeDto } from "./dto/update-resume.dto";
import { JwtAuthGuard } from "../../common/guards/jwt-auth.guard";
import { CurrentUser } from "../../common/decorators/current-user.decorator";
import { FileInterceptor } from "@nestjs/platform-express";
import { memoryStorage } from "multer";
import { UploadService } from "../uploads/upload.service";

@Controller("resumes")
export class ResumesController {
    constructor(
        private readonly resumesService: ResumesService,
        private readonly uploadService: UploadService,
    ) { }

    @Post()
    @UseGuards(JwtAuthGuard)
    create(
        @CurrentUser() user: any,
        @Body() dto: CreateResumeDto,
    ) {
        return this.resumesService.create(
            user.userId,
            dto,
        );
    }

    @Get()
    @UseGuards(JwtAuthGuard)
    findAll(
        @CurrentUser() user: any,
    ) {
        return this.resumesService.findAll(
            user.userId,
        );
    }

    @Get(":id")
    @UseGuards(JwtAuthGuard)
    findOne(
        @CurrentUser() user: any,
        @Param("id") id: string,
    ) {
        return this.resumesService.findOne(
            id,
            user.userId,
        );
    }

    @Patch("photo")
    @UseGuards(JwtAuthGuard)
    @UseInterceptors(
        FileInterceptor("file", {
            storage: memoryStorage(),
            limits: { fileSize: 5 * 1024 * 1024 },
        }),
    )
    async uploadPhoto(
        @CurrentUser() user: any,
        @Body("resumeId") resumeId: string,
        @UploadedFile() file: Express.Multer.File,
    ) {
        const result = await this.uploadService.uploadResumePhoto(file);
        return this.resumesService.updatePhoto(
            resumeId,
            user.userId,
            result.secure_url,
        );
    }

    @Patch(":id")
    @UseGuards(JwtAuthGuard)
    update(
        @CurrentUser() user: any,
        @Param("id") id: string,
        @Body() dto: UpdateResumeDto,
    ) {
        return this.resumesService.update(
            id,
            user.userId,
            dto,
        );
    }

    @Delete(":id")
    @UseGuards(JwtAuthGuard)
    remove(
        @CurrentUser() user: any,
        @Param("id") id: string,
    ) {
        return this.resumesService.remove(
            id,
            user.userId,
        );
    }
}