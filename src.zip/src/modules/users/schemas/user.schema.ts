import {
    Prop,
    Schema,
    SchemaFactory,
} from "@nestjs/mongoose";

import { HydratedDocument } from "mongoose";

import { Role } from "../../../common/constants/role.enum";

import { Status } from "../../../common/constants/status.enum";

export type UserDocument =
    HydratedDocument<User>;

@Schema({
    timestamps: true,
})
export class User {
    @Prop({
        required: true,
        trim: true,
    })
    firstName: string;

    @Prop({
        required: true,
        trim: true,
    })
    lastName: string;

    @Prop({
        required: true,
        unique: true,
        lowercase: true,
    })
    email: string;

    @Prop({
        required: true,
    })
    password: string;

    @Prop({
        type: {
            url: String,
            publicId: String,
        },
        default: {
            url: "",
            publicId: "",
        },
    })
    avatar: {
        url: string;
        publicId: string;
    };

    @Prop({
        enum: Role,
        default: Role.USER,
    })
    role: Role;

    @Prop({
        enum: Status,
        default: Status.ACTIVE,
    })
    status: Status;

    @Prop({
        default: "free",
    })
    plan: string;

    @Prop({
        trim: true,
    })
    headline?: string;

    @Prop({
        trim: true,
    })
    phone?: string;

    @Prop({
        trim: true,
    })
    location?: string;

    @Prop({
        trim: true,
    })
    linkedinUrl?: string;

    @Prop({
        trim: true,
    })
    website?: string;
}

export const UserSchema =
    SchemaFactory.createForClass(User);