import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import * as bcrypt from 'bcrypt';
import { User, UserDocument } from './schemas/user.schema';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { UpdateProfileDto } from './dto/update-profile.dto';

@Injectable()
export class UsersService {
    constructor(@InjectModel(User.name) private readonly userModel: Model<UserDocument>) { }

    async create(dto: CreateUserDto) {
        const existing = await this.userModel.findOne({ email: dto.email }).exec();
        if (existing) throw new ConflictException('Email already in use');

        const hashed = await bcrypt.hash(dto.password, 10);
        const user = await this.userModel.create({ ...dto, password: hashed });
        return this.sanitize(user);
    }

    async findAll() {
        const users = await this.userModel.find().exec();
        return users.map((u) => this.sanitize(u));
    }

    async findById(id: string) {
        const user = await this.userModel.findById(id).exec();
        if (!user) throw new NotFoundException('User not found');
        return this.sanitize(user);
    }

    async findByEmail(email: string) {
        return this.userModel.findOne({ email }).exec();
    }

    async findByEmailWithPassword(email: string) {
        return this.userModel
            .findOne({ email })
            .select("+password");
    }

    async update(id: string, dto: UpdateUserDto) {
        const user = await this.userModel.findByIdAndUpdate(id, dto, { returnDocument: 'after' }).exec();
        if (!user) throw new NotFoundException('User not found');
        return this.sanitize(user);
    }

    async updateProfile(
        userId: string,
        dto: UpdateProfileDto,
    ) {
        const user = await this.userModel.findByIdAndUpdate(
            userId,
            dto,
            {
                returnDocument: 'after',
            },
        ).exec();

        if (!user) throw new NotFoundException('User not found');

        return this.sanitize(user);
    }

    async getProfile(userId: string) {
        const user = await this.userModel.findById(userId).exec();

        if (!user) throw new NotFoundException('User not found');

        return this.sanitize(user);
    }

    async updateAvatar(userId: string, avatar: { url: string; publicId: string }) {
        const user = await this.userModel.findByIdAndUpdate(
            userId,
            { avatar },
            { returnDocument: 'after' },
        ).exec();

        if (!user) throw new NotFoundException('User not found');

        return this.sanitize(user);
    }

    async remove(id: string) {
        const user = await this.userModel.findByIdAndDelete(id).exec();
        if (!user) throw new NotFoundException('User not found');
        return { message: 'User deleted successfully' };
    }

    private sanitize(user: UserDocument) {
        const obj = user.toObject();
        const { password, ...rest } = obj;
        return rest;
    }
}
